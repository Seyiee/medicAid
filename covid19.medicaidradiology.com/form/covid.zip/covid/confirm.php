<?php
    $connection= mysqli_connect("localhost","root","","covid19");
    
    session_start();

    //$veh_id= $_GET['phone']; 

   // $sql= "SELECT * FROM `form` WHERE phone='$veh_id' "; 
    //echo $sql;
   // $res= mysqli_query($connection,$sql);
   // $row= mysqli_fetch_assoc($res);
    $url= "https://covid19.medicaidradiology.com/form/".$_SESSION["url"];
    $_SESSION["email"];
    $_SESSION["phone"];
    $_SESSION["fullname"];
    $_SESSION["bookingdate"];
    $_SESSION["no_of_tests"];
    
?>
<!doctype html>
<html lang="en">
	<head>
		<style>
			/* CSS comes here */
			body {
			    padding:20px;
			}
			input {
			    padding:5px;
			    background-color:transparent;
			    border:none;
			    border-bottom:solid 4px #8c52ff;
			    width:250px;
			    font-size:16px;
			}
			
			.qr-btn {
			    background-color:#8c52ff;
			    padding:8px;
			    color:white;
			    cursor:pointer;
			}
		</style>
		
		<title>THANK YOU FOR YOUR ORDER</title>
	</head>
	<body>
        <center>
        <h3 style="text-align: center;">Dear <?php echo $_SESSION["fullname"]; ?>, Your details have been received </h3><br>
        <h3 style="text-align: center;">Name: <?php echo $_SESSION["fullname"]; ?></h3>
        <h3 style="text-align: center;">Booking Date: <?php echo  $_SESSION["bookingdate"]; ?></h3>
        <h3 style="text-align: center;">No of Tests: <?php echo  $_SESSION["no_of_tests"];?></h3>
        <br/>
        <p id="qr-result">Please Print this Page</p>
        <canvas id="qr-code"></canvas>
        
        </center>
		
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
		<script>
			/* JS comes here */
           
			var qr;
			(function() {
                    qr = new QRious({
                    element: document.getElementById('qr-code'),
                    size: 200,
                    value: 'https://studytonight.com'
                });
            })();
            
            function generateQRCode() {
                var qrtext = '<?php echo $url; ?>';
                
                qr.set({
                    foreground: 'black',
                    size: 200,
                    value: qrtext
                });
            }
            
             window.addEventListener('load', function () {
 generateQRCode();
                
})
		</script>
        
	</body>
</html>